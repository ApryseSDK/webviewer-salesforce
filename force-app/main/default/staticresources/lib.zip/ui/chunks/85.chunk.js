(window.webpackJsonp=window.webpackJsonp||[]).push([[85],{1816:function(n,e,t){t(45)({target:"Number",stat:!0},{isInteger:t(575)})}}]);
//# sourceMappingURL=85.chunk.js.map