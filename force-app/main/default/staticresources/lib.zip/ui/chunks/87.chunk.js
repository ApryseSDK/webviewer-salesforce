(window.webpackJsonp=window.webpackJsonp||[]).push([[87],{1864:function(n,e,t){t(49)({target:"Number",stat:!0},{isInteger:t(582)})}}]);
//# sourceMappingURL=87.chunk.js.map